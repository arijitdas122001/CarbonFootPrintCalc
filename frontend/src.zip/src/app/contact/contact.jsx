import React from 'react'

const Contact = () => {
  return (
    <div>x
      this is contact;
    </div>
  )
}

export default Contact
