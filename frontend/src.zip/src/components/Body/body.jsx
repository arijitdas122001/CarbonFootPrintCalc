import React from 'react'
import styles from './body.module.css'
const Body = () => {
  return (
    <div>
        <div className={styles.container}></div>
    </div>
  )
}

export default Body
